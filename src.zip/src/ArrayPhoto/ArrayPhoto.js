import React, {Component, useState} from 'react'

import { Button, Col, Row } from 'react-bootstrap';
import PhotosArray from '../PhotosArray';
import '../App.css';


export default function ArrayPage(props) { 

  const listPhoto = props.arrayofPhotos.map((item) => {
    
    
    return (

    <div >     
      <PhotosArray value = {item.img_src} />  
    </div>
    )}) 


    
    
            return(
            <div >  
            
              
              <Row><Col>{listPhoto[0]}</Col><Col>{listPhoto[1]}</Col><Col>{listPhoto[2]}</Col><Col>{listPhoto[3]}</Col><Col>{listPhoto[4]}</Col></Row>
              <Row><Col>{listPhoto[5]}</Col><Col>{listPhoto[6]}</Col><Col>{listPhoto[7]}</Col><Col>{listPhoto[8]}</Col><Col>{listPhoto[9]}</Col></Row>
              <Row><Col>{listPhoto[10]}</Col><Col>{listPhoto[11]}</Col><Col>{listPhoto[12]}</Col><Col>{listPhoto[13]}</Col><Col>{listPhoto[14]}</Col></Row>
              <Row><Col>{listPhoto[15]}</Col><Col>{listPhoto[16]}</Col><Col>{listPhoto[17]}</Col><Col>{listPhoto[18]}</Col><Col>{listPhoto[19]}</Col></Row>
              <Row><Col>{listPhoto[20]}</Col><Col>{listPhoto[21]}</Col><Col>{listPhoto[22]}</Col><Col>{listPhoto[23]}</Col><Col>{listPhoto[24]}</Col></Row>
            </div>
            

        )
    }