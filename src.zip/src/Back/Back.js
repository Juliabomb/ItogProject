import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';
import './Back.css';
export default function Back() { 
    
   

     
        return(
        <>
        
        <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'/>
<div id='stars'></div>
<div id='stars2'></div>
<div id='stars3'></div>
<div id='title'></div>
            
         
            
        </>
    )
        }






