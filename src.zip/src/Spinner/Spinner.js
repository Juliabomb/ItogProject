import React, {Component, useState} from 'react'

import { Button, Col, Row } from 'react-bootstrap';
import PhotosArray from '../PhotosArray';
import '../App.css';


export default function Spinner(props) { 




  
  const listPhoto = props.arrayofPhotos.map((item, index) => {
    console.log('arrayofPhotos IMG =' + index)
    
    
    return (
    <div >
     
     
<PhotosArray value = {item.img_src}   />
     
    
    </div>
    )
    }) 


    // function grid (){
    //   for(let z = 0; z < 5; z++){
    //     return(
        
    //   }
    // }
    
   

   
    const pageCount = props.resultCeil; 
    let listPagBtns = new Array (pageCount)
    for (let i = 0; i < listPagBtns.length; i++) {
    listPagBtns[i]= <Button onClick={()=>{ (props.setCurrPage(i) ); } }>
      {i + 1}
    </Button> 
    }
            return(
            <div >  
            
               <div className='pagination-wrapper'>
                {listPagBtns}
              </div>
              
              <Row><Col>{listPhoto[1]}</Col><Col>{listPhoto}</Col></Row>
            
              
            </div>
            

        )
    }