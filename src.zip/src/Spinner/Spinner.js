import React, {Component, useState} from 'react'
import { Button, Col, Row } from 'react-bootstrap';
import PhotosArray from '../PhotosArray';
// import './spinner.css';

export default function Spinner(props) { 

const listPhoto = props.arrayofPhotos.map((item) => 
<div>
<PhotosArray value = {item.img_src} />
  </div>);

const pageCount = 4; // props.resultCeil
console.log('arrayofPhotos IMG =',props.img_src)


const listPagBtns = Array.from({lenght: pageCount}).map((item,index) => {
<Button onClick={()=>{ (props.setCurrPage(item) ); } }>
  {index + 1}
</Button>
}


);
        return(
        <div>  
           
          {listPhoto}
          <div className='pagination-wrapper'>
            {listPagBtns}
          </div>
            
        </div>
    )
}