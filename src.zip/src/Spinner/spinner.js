import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';

export default function Nothing(props) { 
    function spins(){
    if (props.arrayofPhotos.length==0){
        props.setPage(3)
      } else 
      {
        props.setPage(1)
      } }
        return(
        <>
        
           <Button   onClick={()=>{ spins() }} >Типо спиннер</Button>
           
            
            
        </>
    )
}