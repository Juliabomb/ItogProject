import React, {useState} from 'react'
import './styles.css';
import { Form, Button,Row } from 'react-bootstrap';
import DatePicker from 'react-date-picker';
import 'bootstrap/dist/css/bootstrap.min.css';


export default function Components(props) { 
    
    

    return(
        
        <>
            <div className =" formaDiv componentsConteiner text-center">
        
        
        <Form  className="col-12 border rounded p-4 bg-white shadow p-3 mb-5 bg-light rounded">

           <p className = 'Label1 alert-secondary ' ><strong> Выберите вид марсохода</strong>
           <select 
            onChange={(ev) => { ((props.getMarsohod(ev.target.value) ) );  }}
           name="Marsohod" 
           className="custom-select marsohod">
                <option defaultValue="curiosity">curiosity</option>
                <option value="opportunity" >opportunity</option>
                <option value="spirit">spirit</option>
            </select> 
           </p>
            


           <p className = 'Label2 alert-secondary'><strong> Выберите тип камеры</strong>
           
           <select 
           onChange={(evs) => { ((props.setCamera(evs.target.value) ) ); }}
           name="Camera" className="custom-select camera">
                <option value="fhaz">FHAZ</option>
                <option value="rhaz" >RHAZ</option>
                <option value="mast">MAST</option>
                <option value="chemcam">CHEMCAM</option>
                <option value="mahli" >MAHLI</option>
                <option value="mardi">MARDI</option>
                <option value="navcam">NAVCAM</option>
                <option value="pancam">PANCAM</option>
                <option value="minites" >MINITES</option> 
            </select> 
           </p>
           
           <p className = 'Label3 alert-secondary'><strong> Выберите дату</strong>
           
           </p>
           <DatePicker 
           className = 'date '
           format= "y-MM-dd" 
           value={props.startDate} 
           onChange={(date) =>{(props.setStartDate(new Date(date)));}}
            />
           
            <Row className =" button justify-content-center align-items-center text-center">
           <Button
           onClick={(e,ev,evs)=>{
            props.getPhoto(e,ev,evs);
            props.setPage(1);
            // props.setUse(props.startDate, props.marsohod, props.cameraz)
            
            
        }}
           type="submit" 
           className ="btn btn-outline-dark" 
           value="Отправить" > 
           Поиск 
           </Button> 
           </Row>
           
           
        </Form>    
        </div>

       
    </>
        
    )


}