import React, {Component, useState} from 'react'

import './index.css';

export default () =>{ <div style={{display:'flex', justifyContent:'center', margin:'.5rem'}}>
                    <div class="lds-dual-ring"/></div>}