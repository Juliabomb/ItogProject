import React from 'react'


export default function Pagination ({photoPerPage, totalPhoto, paginate}) { 
    const pageNumbers =[];

    for(let i =1; i <= Math.ceil(totalPhoto / photoPerPage); i++){
        pageNumbers.push(i)
    }

    return(
        <div>

<ul className='pagination'>
    {pageNumbers.map(number =>(
<li className='page-item' key = {number}>
    <a href='!#' className='page-link' onClick={() => paginate(number)}>
    {number}    
     </a>
</li>
    ))}
</ul>

        </div>
    )
    
    }