import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';

export default function Nothing(props) { 
        return(
        <>
        
           <h1>Ничего не найдено!</h1>
           <Button  onClick={()=>{props.setPage(0)}} > Назад </Button>
            
            
        </>
    )
}