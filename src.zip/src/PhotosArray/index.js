import React from 'react'
import './styles2.css';

export default function PhotosArray(props) { 
    
        return(
        <div className = 'PhotosArray'> 
         
          <img src={(props.value) } width="100" height="100"  />
        </div>
    )
        }
