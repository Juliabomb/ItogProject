import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';

export default function PhotosArray(props) { 
    
    let srcc = props.value;



     if (!srcc) {
         return ( <h1>Ничего не найдено</h1>)
     }

     else{
        return(
        <>
        
            <img src={(srcc) || (<h1>Ничего не найдено</h1>) }></img>
            
         
            
        </>
    )
        }
}