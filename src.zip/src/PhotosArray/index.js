import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';

export default function PhotosArray(props) { 
    
    

     
        return(
        <>
        

            <img src={(props.value) } width="120" height="131"></img>
            
         
            
        </>
    )
        }
