import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';

export default function PhotosArray(props) { 
    
    let srcc = props.value;

     
        return(
        <>
        
            <img src={(srcc) }></img>
            
         
            
        </>
    )
        }
