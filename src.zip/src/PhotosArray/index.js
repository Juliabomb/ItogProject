import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';
import { Container, Row, Col } from 'react-bootstrap';
import './styles2.css';

export default function PhotosArray(props) { 
    
        return(
        <div className = 'back'> 
         
          <img src={(props.value) } width="120" height="131"  />
        </div>
    )
        }
