import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';
import './styles2.css';
export default function ButtonExit(props) { 
        return(
        <div className='back'>
            
            <button  
            onClick={()=>{ props.setPage(0); props.lengthNul() }} 
            type="submit"> 
            Назад 
            </button>
            
            
            
        </div>
    )
}