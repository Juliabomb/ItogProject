import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';

export default function ButtonExit(props) { 
        return(
        <>
            
            <Button  onClick={()=>{ props.setPage(0); }} > Назад </Button>
            
            
            
        </>
    )
}