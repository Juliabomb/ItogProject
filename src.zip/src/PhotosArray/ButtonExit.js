import React, {Component, useState} from 'react'
import { Button } from 'react-bootstrap';
import './styles2.css';
export default function ButtonExit(props) { 
        return(
        <div className='back'>
            
            <Button  onClick={()=>{ props.setPage(0); }} > Назад </Button>
            
            
            
        </div>
    )
}