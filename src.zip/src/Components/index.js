import React, {useState} from 'react'
import './styles.css';
import { Form, Button } from 'react-bootstrap';
import DatePicker from 'react-date-picker';
import 'bootstrap/dist/css/bootstrap.min.css';


export default function Components(props) { 
    
        const [startDate, setStartDate] = useState(new Date());
        
          
    
      

    return(
        
        <>
            <div className ="  row h-100 justify-content-center align-items-center text-center">
        
        
        <Form  className="col-12 border rounded p-4 bg-white shadow p-3 mb-5 bg-light rounded">

           <p className = 'Label1 alert-secondary ' ><strong> Выберите вид марсохода</strong>
           <select 
            onChange={(ev) => { ((props.getMarsohod(ev.target.value) ) );  }}
           name="Marsohod" 
           className="custom-select marsohod">
                <option defaultValue="curiosity">curiosity</option>
                <option value="opportunity" >opportunity</option>
                <option value="spirit">spirit</option>
            </select> 
           </p>
            


           <p className = 'Label2 alert-secondary'><strong> Выберите тип камеры</strong>
           
           <select 
       
           name="Camera" className="custom-select camera">
                <option defaultValue="FHAZ">FHAZ</option>
                <option value="RHAZ" >RHAZ</option>
                <option value="MAST">MAST</option>
                <option value="CHEMCAM">CHEMCAM</option>
                <option value="MAHLI" >MAHLI</option>
                <option value="MARDI">MARDI</option>
                <option value="NAVCAM">NAVCAM</option>
                <option value="PANCAM">PANCAM</option>
                <option value="MINITES" >MINITES</option> 
            </select> 
           </p>
           
           <p className = 'Label3 alert-secondary'><strong> Выберите дату</strong>
             <Form.Control onChange={(e) => { (props.PhotoDate(e.target.value)) ;  }} 
              type ="text" 
              name = "earth_date1" 
              placeholder="ГГГГ-ММ-ДД"/>
           </p>
            
           <DatePicker format= "y-MM-dd" value={startDate} onChange={(date) => setStartDate(date)} />

           <Button
           onClick={(e,ev)=>{props.getPhotoDate(e,ev); props.setPage(1)}}
           type="submit" 
           className ="btn btn-outline-dark" 
           value="Отправить" > 
           Поиск 
           </Button> 
           
           
        </Form>    
        </div>

        <div>
           
        </div>
</>
        
    )


}