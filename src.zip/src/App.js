import React, {useState} from 'react'
import Components from './Components/index';
import PhotosArray from './PhotosArray';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';
import ButtonExit from './PhotosArray/ButtonExit';


function App() {

  const apykey = "tgWrGbAq8XdprDbZnS3oj7H27PtSqYloBNYvzWRN";

    const [page, setPage] = useState(0);

    const [startDate, setStartDate] = useState(new Date()); 

    const [marsohod, setMarsohod] = useState("curiosity");
    const [cameraz, setCamera] = useState("FHAZ");
    const [earthdate, setEarthdate] = useState(" ");
    const [arrayofPhotos, setArrayofPhotos] = useState([]);

    const getPhoto = (e) =>{
        
        fetch(`https://api.nasa.gov/mars-photos/api/v1/rovers/${marsohod}/photos?earth_date=${startDate.getUTCFullYear()+'-'+(startDate.getMonth()+1)+'-'+startDate.getDate()}&page=2&api_key=${apykey}`)
        // camera=${cameraz}&
        .then((api_url)=>{return api_url.json();})
        .then((datas)=>{setArrayofPhotos(datas.photos)})
        // e.preventDefault();
       
    }

  return (
    <>
      <Container>
        <Container className = ' h-50 w-50   conteiner1'>
        {(page===0 && (<Components setPage = {setPage} getPhotoDate = {getPhoto} PhotoDate = {setEarthdate} getMarsohod = {setMarsohod} setCamera = {setCamera} setStartDate={setStartDate} startDate={startDate}/>)) }
     </Container>
     <Col>{(page===1 && (<ButtonExit setPage = {setPage}/>))}</Col>
     
 
 {/* {console.log(arrayofPhotos[0])} */}
 
      {   (page===1 &&   (arrayofPhotos.map((item)=>{
          return (<PhotosArray  value={item.img_src}/>)
      })  )   )} 
      {/* JSON.stringify(data1) */} 
      
      </Container>
  
    </>
  );
}

export default App;
