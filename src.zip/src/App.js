import React, {useState} from 'react'
import Components from './Components/index';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';
import ButtonExit from './PhotosArray/ButtonExit';
import Nothing from './PhotosArray/Nothing';
import Spinner from './Spinner/Spinner';
import Back from './Back/Back';

function App() {

  const apykey = "tgWrGbAq8XdprDbZnS3oj7H27PtSqYloBNYvzWRN";

    const [page, setPage] = useState(0);

    const [currPage, setCurrPage] = useState('');

    const [startDate, setStartDate] = useState(new Date()); 
    const [marsohod, setMarsohod] = useState("curiosity");
    const [cameraz, setCamera] = useState("rhaz");

    const [arrayofPhotos, setArrayofPhotos] = useState([]);


    const getPhoto = () =>{
          
      let apiUrl = `https://api.nasa.gov/mars-photos/api/v1/rovers/${marsohod}/photos?earth_date=${startDate.getFullYear()+'-'+(startDate.getMonth()+1)+'-'+startDate.getDate()}&camera=${cameraz}&api_key=${apykey}`
 
      console.log('apiUrl = ',apiUrl)

      fetch(apiUrl)
      .then(async (response)=>{
        if (response.ok){
          let json = await response.json();
          return json;

        } else {
          alert ('Ошибка HTTP :'+ response.status);
        }

      }) 
      

      .then((datas)=> {
        setArrayofPhotos(datas.photos)})
      
      
  }




const resultCeil = Math.ceil(arrayofPhotos.length/25); 

  return (
    <>

      <Container >
        <Container className = ' h-50 w-50   conteiner1'>
        {(page===0  && (<Back />)) }
        {(page===0 && (<Components className='componentsConteiner'  setPage = {setPage} getPhotoDate = {getPhoto}  getMarsohod = {setMarsohod} setCamera = {setCamera} setStartDate={setStartDate} startDate={startDate} />) ) }
        
     </Container>

     <Container >
     {(page===1 && ( <Container fluid className=' pageImg'><ButtonExit  setPage = {setPage}/> </Container >))}
     
     {(page===3 &&(<Nothing setPage = {setPage}/>))}
 
     {(page===1 &&(<Spinner className=' pageImg' resultCeil={resultCeil} setCurrPage={setCurrPage}  arrayofPhotos={arrayofPhotos} setPage = {setPage}/>))}
       
        </Container>

      </Container>
  
    
            
    </>
  );
}

export default App;
