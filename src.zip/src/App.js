import React, {useEffect, useState} from 'react'
import Components from './Form/index';
import { Container, Row, Col} from 'react-bootstrap';
import './App.css';
import ButtonExit from './PhotosArray/ButtonExit';
import Nothing from './PhotosArray/Nothing';
import ArrayPhoto from './ArrayPhoto/ArrayPhoto';
import Back from './Back/Back';
import Pagination from './Pagination/Pagination';


function App() {
  
  const apykey = "tgWrGbAq8XdprDbZnS3oj7H27PtSqYloBNYvzWRN";


  
//какой элемент будет скрыт\отображен
    const [page, setPage] = useState(0);

//какая страница будет отображена браузером
    const [currentPage, setCurrentPage] = useState(1);
// кол-во элементов , которые будут отображаться на страничке
    const [photoPerPage] = useState(25);

//критерии для поиска фото
    const [startDate, setStartDate] = useState(new Date()); 
    const [marsohod, setMarsohod] = useState("curiosity");
    const [cameraz, setCamera] = useState("rhaz");
//массив объектов
    const [arrayofPhotos, setArrayofPhotos] = useState([]);

  
    const getPhoto = () =>{
       
      
      let apiUrl = `https://api.nasa.gov/mars-photos/api/v1/rovers/${marsohod}/photos?earth_date=${startDate.getFullYear()+'-'+(startDate.getMonth()+1)+'-'+startDate.getDate()}&camera=${cameraz}&api_key=${apykey}`
 
      console.log('apiUrl = ',apiUrl)

      fetch(apiUrl)
      .then(async (response)=>{
        if (response.ok){
          let json = await response.json();
          return json;
        } else {
          alert ('Ошибка HTTP :'+ response.status);
        }

      }) 
      
      .then((datas)=> {
        console.log('datas.photos',datas.photos.length)

          if(datas.photos.length!=0){

          setArrayofPhotos(datas.photos) 
        } else {
          alert ('Ничего не найдено')
        }})   
  } 

  const lastPhotoIndex = currentPage * photoPerPage;
 const firstPhotoIndex = lastPhotoIndex - photoPerPage;
const currentPhoto = arrayofPhotos.slice(firstPhotoIndex, lastPhotoIndex);

const paginate = pageNumber => setCurrentPage(pageNumber);



function lengthNul ()  {arrayofPhotos.length = 0}

  return (
    <>

      <Container >
        <Container className = ' h-50 w-50   conteiner1'>
        {(page===0  && (<Back />)) }
        {(page===0 && (<Components className='componentsConteiner'  setPage = {setPage} 
        getPhoto = {getPhoto}  
        getMarsohod = {setMarsohod} 
        setCamera = {setCamera} 
        setStartDate={setStartDate} 
        startDate={startDate} />) ) }
        
     </Container>

     <Container >
     
     {(page===1 && ( <Container fluid className=' pageImg'><ButtonExit lengthNul={lengthNul} setPage = {setPage}/> </Container >))}
     
     {(page===3 &&(<Nothing setPage = {setPage}/>))}
 
     {(page===1 &&(<ArrayPhoto className=' pageImg'  arrayofPhotos={currentPhoto} setPage = {setPage}/>))}

     {(page===1 &&(<Pagination photoPerPage={photoPerPage} 
     totalPhoto={arrayofPhotos.length} 
     paginate ={paginate}
     />))}
       
        </Container>

      </Container>
  
    
            
    </>
  );
}

export default App;
