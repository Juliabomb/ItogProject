import React, {useState} from 'react'
import Components from './Components/index';
import PhotosArray from './PhotosArray';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';
import ButtonExit from './PhotosArray/ButtonExit';
import Nothing from './PhotosArray/Nothing';
import Spinner from './Spinner/spinner';

function App() {

  const apykey = "tgWrGbAq8XdprDbZnS3oj7H27PtSqYloBNYvzWRN";

    const [page, setPage] = useState(0);

    const [startDate, setStartDate] = useState(new Date()); 
    const [marsohod, setMarsohod] = useState("curiosity");
    const [cameraz, setCamera] = useState("rhaz");

    const [arrayofPhotos, setArrayofPhotos] = useState([]);

    const getPhoto = (e) =>{
          
        let link = `https://api.nasa.gov/mars-photos/api/v1/rovers/${marsohod}/photos?earth_date=${startDate.getFullYear()+'-'+(startDate.getMonth()+1)+'-'+startDate.getDate()}&camera=${cameraz}&api_key=${apykey}`
      //  больше 25 фото 2015-06-30
       
        console.log('link = ',link)
        fetch(link)

        .then((api_url)=>{return api_url.json();})
        .then((datas)=>{setArrayofPhotos(datas.photos)})
        // e.preventDefault();

      
       

         

    
     
      
        

    }
    

   
    console.log('arrayofPhotos length =',arrayofPhotos.length)
console.log('arrayofPhotos =',arrayofPhotos)



 

  return (
    <>
      <Container>
        <Container className = ' h-50 w-50   conteiner1'>
        {(page===0 && (<Components   setPage = {setPage} getPhotoDate = {getPhoto}  getMarsohod = {setMarsohod} setCamera = {setCamera} setStartDate={setStartDate} startDate={startDate} />)) }
     </Container>
     <Col>{(page===1 && (<ButtonExit  setPage = {setPage}/>))}</Col>
     
     <Col>{(page===3 &&(<Nothing setPage = {setPage}/>))}</Col>
 
     <Col>{(page===4 &&(<Spinner arrayofPhotos={arrayofPhotos} setPage = {setPage}/>))}</Col>
 
      {   (page===1 &&   (arrayofPhotos.map((item)=>{
          return (<PhotosArray  value={item.img_src}/>)
      })  )   )} 
      
      
      </Container>
  
    </>
  );
}

export default App;
