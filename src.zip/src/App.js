import React, {useEffect, useState} from 'react'
import Components from './Form/index';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';
import ButtonExit from './PhotosArray/ButtonExit';
import Nothing from './PhotosArray/Nothing';
import Spinner from './ArrayPage/ArrayPage';
import Back from './Back/Back';
import Loader from './Loader/Loader';

function App() {
  
  const apykey = "tgWrGbAq8XdprDbZnS3oj7H27PtSqYloBNYvzWRN";


  // const [loading, setLoading] = useState(true);
//какой элемент будет скрыт\отображен
    const [page, setPage] = useState(0);
//какая страница будет отображена браузером
    const [currPage, setCurrPage] = useState('');
//критерии для поиска фото
    const [startDate, setStartDate] = useState(new Date()); 
    const [marsohod, setMarsohod] = useState("curiosity");
    const [cameraz, setCamera] = useState("rhaz");
//массив объектов
    const [arrayofPhotos, setArrayofPhotos] = useState([]);

  // useEffect(() =>{
    const getPhoto = () =>{
       
      
      let apiUrl = `https://api.nasa.gov/mars-photos/api/v1/rovers/${marsohod}/photos?earth_date=${startDate.getFullYear()+'-'+(startDate.getMonth()+1)+'-'+startDate.getDate()}&camera=${cameraz}&api_key=${apykey}`
 
      console.log('apiUrl = ',apiUrl)

      fetch(apiUrl)
      .then(async (response)=>{
        if (response.ok){
          let json = await response.json();
          return json;
        } else {
          alert ('Ошибка HTTP :'+ response.status);
        }

      }) 
      
      .then((datas)=> {
        console.log('datas.photos',datas.photos.length)

          if(datas.photos.length!=0){

          setArrayofPhotos(datas.photos) 
        } else {
          alert ('Ничего не найдено')
        }
        
        })
        
        
      
  } 
// },[use])

function lengthNul ()  {arrayofPhotos.length = 0}

const resultCeil = Math.ceil(arrayofPhotos.length/25); 

  return (
    <>

      <Container >
        <Container className = ' h-50 w-50   conteiner1'>
        {(page===0  && (<Back />)) }
        {(page===0 && (<Components className='componentsConteiner'  setPage = {setPage} 
        getPhoto = {getPhoto}  
        // setUse={setUse}
        // startDate = {startDate} marsohod={marsohod}  cameraz={cameraz}

        getMarsohod = {setMarsohod} setCamera = {setCamera} setStartDate={setStartDate} startDate={startDate} />) ) }
        
     </Container>

     <Container >
     {/* {loading && <Loader/>}  */}
     {(page===1 && ( <Container fluid className=' pageImg'><ButtonExit lengthNul={lengthNul} setPage = {setPage}/> </Container >))}
     
     {(page===3 &&(<Nothing setPage = {setPage}/>))}
 
     {(page===1 &&(<Spinner className=' pageImg' resultCeil={resultCeil} setCurrPage={setCurrPage}  arrayofPhotos={arrayofPhotos} setPage = {setPage}/>))}
       
        </Container>

      </Container>
  
    
            
    </>
  );
}

export default App;
